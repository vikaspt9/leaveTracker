/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.apps.leavetracker.manager.employee.entitybean;

/**
 *
 * @author Administrator
 */
public class LeaveWfhBean {

    private int SRNO;
    private String EMP_ID;
    private String ENTRY_DATE;
    private String LEAVE_TYPE;

    public String getEMP_ID() {
        return EMP_ID;
    }

    public void setEMP_ID(String EMP_ID) {
        this.EMP_ID = EMP_ID;
    }

    public String getENTRY_DATE() {
        return ENTRY_DATE;
    }

    public void setENTRY_DATE(String ENTRY_DATE) {
        this.ENTRY_DATE = ENTRY_DATE;
    }

    public String getLEAVE_TYPE() {
        return LEAVE_TYPE;
    }

    public void setLEAVE_TYPE(String LEAVE_TYPE) {
        this.LEAVE_TYPE = LEAVE_TYPE;
    }

    public int getSRNO() {
        return SRNO;
    }

    public void setSRNO(int SRNO) {
        this.SRNO = SRNO;
    }
}
