/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.apps.leavetracker.manager.employee.entitybean;

/**
 *
 * @author Administrator
 */
public class EmployeeBean {

    private String EMP_ID;
    private String PASSWORD;
    private String FIRST_NAME;
    private String LAST_NAME;
    private long CONTACT_NO;
    private String EMAIL;
    private int IS_ADMIN;

    public long getCONTACT_NO() {
        return CONTACT_NO;
    }

    public void setCONTACT_NO(long CONTACT_NO) {
        this.CONTACT_NO = CONTACT_NO;
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public void setEMAIL(String EMAIL) {
        this.EMAIL = EMAIL;
    }

    public String getEMP_ID() {
        return EMP_ID;
    }

    public void setEMP_ID(String EMP_ID) {
        this.EMP_ID = EMP_ID;
    }

    public String getFIRST_NAME() {
        return FIRST_NAME;
    }

    public void setFIRST_NAME(String FIRST_NAME) {
        this.FIRST_NAME = FIRST_NAME;
    }

    public String getLAST_NAME() {
        return LAST_NAME;
    }

    public void setLAST_NAME(String LAST_NAME) {
        this.LAST_NAME = LAST_NAME;
    }

    public String getPASSWORD() {
        return PASSWORD;
    }

    public void setPASSWORD(String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public int getIS_ADMIN() {
        return IS_ADMIN;
    }

    public void setIS_ADMIN(int IS_ADMIN) {
        this.IS_ADMIN = IS_ADMIN;
    }
}
