/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.apps.leavetracker.dao.normaluser;

import com.ibm.apps.leavetracker.formbean.LeaveRptFormBean;
import com.ibm.apps.leavetracker.manager.employee.entitybean.EmployeeBean;
import com.ibm.apps.leavetracker.manager.employee.entitybean.LeaveWfhBean;
import java.util.List;
import java.util.Map;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

/**
 *
 * @author Administrator
 */
public interface NormalUserDAO {

    public EmployeeBean getUser(Map dataMap);

    public boolean validateUser(Map DataMap);

    public boolean addUser(EmployeeBean eb);

    public List listUser(EmployeeBean eb);

    public boolean addLeave(LeaveWfhBean eb);

    public boolean updateUser(EmployeeBean eb);

    public List getLeaveReport(LeaveRptFormBean fb);

    public boolean deleteLeave(Map inputMap);

    public DefaultPieDataset getLeaveSummery(String leaveType);
}
