/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.apps.leavetracker.model;

import com.ibm.apps.leavetracker.dao.normaluser.NormalUserDAO;
import com.ibm.apps.leavetracker.manager.employee.entitybean.EmployeeBean;
import java.util.Map;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 *
 * @author Administrator
 */
public class LoginServiceModel {

    ApplicationContext context;

    public boolean validateUser(Map DataMap) throws Exception {

        boolean returnFlg = false;
        try {
            //ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            returnFlg = normalUserDAO.validateUser(DataMap);
        } catch (Exception ex) {
            throw ex;
        }

        return returnFlg;
    }

    public EmployeeBean getUser(Map dataMap) throws Exception {
        EmployeeBean eb = null;
        try {
            eb = new EmployeeBean();
            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            eb = normalUserDAO.getUser(dataMap);
        } catch (Exception ex) {
            throw ex;
        }

        return eb;
    }
}
