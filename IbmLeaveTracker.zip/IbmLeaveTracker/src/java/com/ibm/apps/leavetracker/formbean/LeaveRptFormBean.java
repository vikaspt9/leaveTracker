/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.apps.leavetracker.formbean;

/**
 *
 * @author Administrator
 */
public class LeaveRptFormBean {

    private String cmbEmp;
    private int cmbFromDay;
    private int cmbFromMonth;
    private int cmbFromYear;
    private int cmbToDay;
    private int cmbToMonth;
    private int cmbToYear;
    private String cmbLeaveType;
    private String rptType;
    private String exportType;

    public String getCmbEmp() {
        return cmbEmp;
    }

    public void setCmbEmp(String cmbEmp) {
        this.cmbEmp = cmbEmp;
    }

    public int getCmbFromDay() {
        return cmbFromDay;
    }

    public void setCmbFromDay(int cmbFromDay) {
        this.cmbFromDay = cmbFromDay;
    }

    public int getCmbFromMonth() {
        return cmbFromMonth;
    }

    public void setCmbFromMonth(int cmbFromMonth) {
        this.cmbFromMonth = cmbFromMonth;
    }

    public int getCmbFromYear() {
        return cmbFromYear;
    }

    public void setCmbFromYear(int cmbFromYear) {
        this.cmbFromYear = cmbFromYear;
    }

    public String getCmbLeaveType() {
        return cmbLeaveType;
    }

    public void setCmbLeaveType(String cmbLeaveType) {
        this.cmbLeaveType = cmbLeaveType;
    }

    public int getCmbToDay() {
        return cmbToDay;
    }

    public void setCmbToDay(int cmbToDay) {
        this.cmbToDay = cmbToDay;
    }

    public int getCmbToMonth() {
        return cmbToMonth;
    }

    public void setCmbToMonth(int cmbToMonth) {
        this.cmbToMonth = cmbToMonth;
    }

    public int getCmbToYear() {
        return cmbToYear;
    }

    public void setCmbToYear(int cmbToYear) {
        this.cmbToYear = cmbToYear;
    }

    public String getExportType() {
        return exportType;
    }

    public void setExportType(String exportType) {
        this.exportType = exportType;
    }

    public String getRptType() {
        return rptType;
    }

    public void setRptType(String rptType) {
        this.rptType = rptType;
    }
}
