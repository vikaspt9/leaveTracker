/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.apps.leavetracker.controller;

import com.ibm.apps.leavetracker.manager.employee.entitybean.EmployeeBean;
import com.ibm.apps.leavetracker.model.LoginServiceModel;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

/**
 *
 * @author Administrator
 */
public class LoginController extends MultiActionController {

    public ModelAndView defaultMethod(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("login/login");

        return mv;
    }

    public ModelAndView validateUser(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        LoginServiceModel objModel = new LoginServiceModel();
        Map dataMap = new HashMap();

        try {

            String userName = req.getParameter("txtLogin");
            String password = req.getParameter("txtPwd");

            dataMap.put("EMPID", userName);
            dataMap.put("PASSWORD", password);

            if (objModel.validateUser(dataMap)) {

                EmployeeBean eb = new EmployeeBean();
                eb = objModel.getUser(dataMap);

                HttpSession session = req.getSession(true);
                session.setAttribute("EMP_ID", eb.getEMP_ID());
                session.setAttribute("FIRST_NAME", eb.getFIRST_NAME());
                session.setAttribute("LAST_NAME", eb.getLAST_NAME());
                session.setAttribute("IS_ADMIN", eb.getIS_ADMIN());
                mv.setViewName("success");

                if (eb.getIS_ADMIN() != 1) {
                    mv.addObject("URL", "index.htm");
                } else {
                    mv.addObject("URL", "admin.htm");// for admin login
                }


            } else {
                mv.setViewName("login/login");
                mv.addObject("Error", "Invalid User Name/password");
            }
        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
            try {
                throw ex;
            } catch (Exception ex1) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex1);
            }

        }



        return mv;
    }
}
