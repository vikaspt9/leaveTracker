/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.apps.leavetracker.model;

import com.ibm.apps.leavetracker.dao.normaluser.NormalUserDAO;
import com.ibm.apps.leavetracker.formbean.LeaveRptFormBean;
import com.ibm.apps.leavetracker.manager.employee.entitybean.EmployeeBean;
import com.ibm.apps.leavetracker.manager.employee.entitybean.LeaveWfhBean;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 *
 * @author Administrator
 */
public class AdminServiceModel {

    ApplicationContext context;

    public boolean addUser(EmployeeBean eb) throws Exception {
        boolean returnFlg = false;
        System.out.print("HERE IN MODEL");
        try {

            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            returnFlg = normalUserDAO.addUser(eb);
        } catch (Exception ex) {
            throw ex;
        }

        return returnFlg;
    }

    public List lisUser(EmployeeBean eb) throws Exception {

        List<EmployeeBean> returnList = new ArrayList<EmployeeBean>();
        try {

            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            returnList = normalUserDAO.listUser(eb);
        } catch (Exception ex) {
            throw ex;
        }

        return returnList;
    }

    public boolean addLeave(LeaveWfhBean eb) throws Exception {
        boolean returnFlg = false;
        try {

            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            returnFlg = normalUserDAO.addLeave(eb);
        } catch (Exception ex) {
            throw ex;
        }
        return returnFlg;
    }

    public EmployeeBean getUser(Map dataMap) throws Exception {
        EmployeeBean eb = new EmployeeBean();
        try {

            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            eb = normalUserDAO.getUser(dataMap);
        } catch (Exception ex) {
            throw ex;
        }

        return eb;
    }

    public boolean updateUser(EmployeeBean eb) throws Exception {
        boolean returnFlg = false;
        try {

            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            returnFlg = normalUserDAO.updateUser(eb);
        } catch (Exception ex) {
            throw ex;
        }

        return returnFlg;
    }

    public List getLeaveReport(LeaveRptFormBean fb) throws Exception {
        List returnList = new ArrayList();
        try {
            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            returnList = normalUserDAO.getLeaveReport(fb);
        } catch (Exception ex) {
            throw ex;
        }

        return returnList;
    }

    public boolean deleteLeave(Map inputMap) {
        boolean returnFlg = false;
        try {

            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            returnFlg = normalUserDAO.deleteLeave(inputMap);
        } catch (Exception ex) {
            try {
                throw ex;
            } catch (Exception ex1) {
                Logger.getLogger(AdminServiceModel.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }

        return returnFlg;
    }

    public DefaultPieDataset getLeaveSummery(String string) throws Exception {
        DefaultPieDataset dataset = null;
        try {

            context = new FileSystemXmlApplicationContext("C:/java_projects/IbmLeaveTracker/web/WEB-INF/applicationContext.xml");
            NormalUserDAO normalUserDAO = (NormalUserDAO) context.getBean("normalUserDAO");
            dataset = normalUserDAO.getLeaveSummery(string);
        } catch (Exception ex) {
           throw ex;
        }
        return dataset;
    }
}
