/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.apps.leavetracker.controller;

import com.ibm.apps.leavetracker.formbean.LeaveRptFormBean;
import com.ibm.apps.leavetracker.manager.employee.entitybean.EmployeeBean;
import com.ibm.apps.leavetracker.manager.employee.entitybean.LeaveWfhBean;
import com.ibm.apps.leavetracker.model.AdminServiceModel;
import com.ibm.common.commonFunctions;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jfree.data.general.DefaultPieDataset;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

/**
 *
 * @author Administrator
 */
public class AdminController extends MultiActionController {

    private AdminServiceModel objModel;

    public ModelAndView defaultMethod(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/admin");

        return mv;
    }

    public ModelAndView addUser(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/addUser");
        mv.addObject("task", "add");

        return mv;
    }

    public ModelAndView editUser(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/addUser");
        mv.addObject("task", "edit");
        Map dataMap = new HashMap();
        objModel = new AdminServiceModel();
        EmployeeBean eb = new EmployeeBean();
        try {
            dataMap.put("EMPID", req.getParameter("empid"));
            eb = objModel.getUser(dataMap);
            mv.addObject("EMP", eb);
        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
            try {
                throw ex;
            } catch (Exception ex1) {
            }
        }
        return mv;
    }

    public ModelAndView insertUser(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/ajaxResponse");
        System.out.print("HERE IN CONTROLLER");
        EmployeeBean eb = new EmployeeBean();

        try {
            eb.setEMP_ID(req.getParameter("txtEmpId"));
            eb.setPASSWORD(req.getParameter("txtEmpPwd"));
            eb.setFIRST_NAME(req.getParameter("txtFirstName"));
            eb.setLAST_NAME(req.getParameter("txtLastName"));
            long i = Long.parseLong(req.getParameter("txtContact").trim());
            eb.setCONTACT_NO(i);
            eb.setEMAIL(req.getParameter("txtEmail"));
            eb.setIS_ADMIN(Integer.parseInt(req.getParameter("isAdmin")));

            objModel = new AdminServiceModel();
            mv.addObject("OPT", "ONE");
            if (objModel.addUser(eb)) {
                mv.addObject("MSG", "Employee added successfully.");
            } else {
                mv.addObject("MSG", "There is some technical problem, Please try later.!!");
            }

        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
            try {
                throw ex;
            } catch (Exception ex1) {
            }

        }
        return mv;
    }

    public ModelAndView updateUser(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/ajaxResponse");

        EmployeeBean eb = new EmployeeBean();

        try {
            eb.setEMP_ID(req.getParameter("txtEmpId"));
            eb.setPASSWORD(req.getParameter("txtEmpPwd"));
            eb.setFIRST_NAME(req.getParameter("txtFirstName"));
            eb.setLAST_NAME(req.getParameter("txtLastName"));
            long i = Long.parseLong(req.getParameter("txtContact").trim());
            eb.setCONTACT_NO(i);
            eb.setEMAIL(req.getParameter("txtEmail"));
            eb.setIS_ADMIN(Integer.parseInt(req.getParameter("isAdmin")));

            objModel = new AdminServiceModel();
            mv.addObject("OPT", "ONE");
            if (objModel.updateUser(eb)) {
                mv.addObject("MSG", "Employee updated successfully.");
            } else {
                mv.addObject("MSG", "There is some technical problem, Please try later.!!");
            }

        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
            try {
                throw ex;
            } catch (Exception ex1) {
            }

        }

        return mv;
    }

    public ModelAndView listUser(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/listUser");
        List<EmployeeBean> returnList = new ArrayList<EmployeeBean>();

        try {
            objModel = new AdminServiceModel();
            returnList = objModel.lisUser(null);
            mv.addObject("returnList", returnList);
            System.out.println("SIZE in controller===>" + returnList.size());
        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
            try {
                throw ex;
            } catch (Exception ex1) {
            }
        }

        return mv;

    }

    public ModelAndView addLeave(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView("admin/addLeave");
        List<EmployeeBean> returnList = new ArrayList<EmployeeBean>();

        try {
            objModel = new AdminServiceModel();
            returnList = objModel.lisUser(null);
            mv.addObject("returnList", returnList);

        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
            try {
                throw ex;
            } catch (Exception ex1) {
            }
        }

        return mv;
    }

    public ModelAndView insertLeave(HttpServletRequest req, HttpServletResponse res) {

        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/ajaxResponse");
        LeaveWfhBean eb = new LeaveWfhBean();
        objModel = new AdminServiceModel();
        String mnth = "";
        String day = "";
        String leaveDate = "";
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

        try {

            eb.setEMP_ID(req.getParameter("cmbEmp"));
            eb.setLEAVE_TYPE(req.getParameter("cmbLeaveType"));

            if (req.getParameter("radioEntryType").equalsIgnoreCase("INDIVIDUAL")) {
                if (Integer.parseInt(req.getParameter("cmbMonth").toString()) <= 9) {
                    mnth = "0" + req.getParameter("cmbMonth");
                } else {
                    mnth = req.getParameter("cmbMonth");
                }

                if (Integer.parseInt(req.getParameter("cmbDay").toString()) <= 9) {
                    day = "0" + req.getParameter("cmbDay");
                } else {
                    day = req.getParameter("cmbDay");
                }

                leaveDate = req.getParameter("cmbYear") + "-" + mnth + "-" + day;
                eb.setENTRY_DATE(leaveDate);

                if (objModel.addLeave(eb)) {
                    mv.addObject("MSG", "Leave/WFH added successfully.");
                } else {
                    mv.addObject("MSG", "There is some technical problem, Please try later.!!");
                }

            } else {

                Calendar startDate = new GregorianCalendar();

                startDate.set(Integer.parseInt(req.getParameter("cmbFromYear")), Integer.parseInt(req.getParameter("cmbFromMonth")) - 1,
                        Integer.parseInt(req.getParameter("cmbFromDay")), 0, 0, 0);
                System.out.println(df.format(startDate.getTime()));
                startDate.set(Calendar.MILLISECOND, 0);
                System.out.println(df.format(startDate.getTime()));

                Calendar endDate = new GregorianCalendar();
                endDate.set(Integer.parseInt(req.getParameter("cmbToYear")), Integer.parseInt(req.getParameter("cmbToMonth")) - 1,
                        Integer.parseInt(req.getParameter("cmbToDay")), 0, 0, 0);
                endDate.set(Calendar.MILLISECOND, 0);

                Calendar entryDate;
                entryDate = startDate;
                while (startDate.before(endDate) || startDate.equals(endDate)) {
                    eb.setENTRY_DATE(df.format(entryDate.getTime()));

                    if (objModel.addLeave(eb)) {
                        mv.addObject("MSG", "Leave/WFH added successfully.");
                    } else {
                        mv.addObject("MSG", "There is some technical problem, Please try later.!!");
                    }
                    entryDate.add(Calendar.DATE, 1);
                }
            }



        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
            try {
                throw ex;
            } catch (Exception ex1) {
            }

        }

        mv.addObject("OPT", "ONE");

        return mv;
    }

    public ModelAndView DeleteLeaveReport(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/ajaxResponse");

        objModel = new AdminServiceModel();

        try {
            Map inputMap = new HashMap();
            String[] srno = req.getParameterValues("chkDelDate");
            String leaveID = "";
            for (int i = 0; i < srno.length; i++) {
                leaveID += srno[i] + ",";
            }

            if (leaveID != null && !leaveID.equals("")) {
                leaveID.substring(0, leaveID.lastIndexOf(","));
            }
            inputMap.put("SRNO", leaveID);
            if (objModel.deleteLeave(inputMap)) {
                mv.addObject("MSG", "Leave/WFH deleted successfully.");
            } else {
                mv.addObject("MSG", "There is some technical problem, Please try later.!!");
            }

        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
            try {
                throw ex;
            } catch (Exception ex1) {
            }

        }

        mv.addObject("OPT", "ONE");
        return mv;
    }

    public ModelAndView viewLeave(HttpServletRequest req, HttpServletResponse res) {

        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/leaveRptMenu");

        List<EmployeeBean> returnList = new ArrayList<EmployeeBean>();



        try {
            objModel = new AdminServiceModel();
            returnList = objModel.lisUser(null);
            mv.addObject("returnList", returnList);



        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();


            try {
                throw ex;


            } catch (Exception ex1) {
            }
        }

        return mv;



    }

    public ModelAndView deleteLeave(HttpServletRequest req, HttpServletResponse res) {

        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/deleteLeaveMenu");
        List<EmployeeBean> returnList = new ArrayList<EmployeeBean>();



        try {
            objModel = new AdminServiceModel();
            returnList = objModel.lisUser(null);
            mv.addObject("returnList", returnList);



        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();


            try {
                throw ex;


            } catch (Exception ex1) {
            }
        }

        return mv;


    }

    public ModelAndView getReport(HttpServletRequest req, HttpServletResponse res, LeaveRptFormBean fb) {

        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/leaveRpt");
        List returnList = new ArrayList();



        try {
            mv.addObject("RPTTYPE", fb.getRptType());
            returnList = objModel.getLeaveReport(fb);


            if (returnList.size() > 0) {
                mv.addObject("returnList", returnList);


            } else {
                mv.addObject("returnList", null);


            }
        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();


            try {
                throw ex;


            } catch (Exception ex1) {
            }
        }



        return mv;


    }

    public ModelAndView getDeleteReport(HttpServletRequest req, HttpServletResponse res, LeaveRptFormBean fb) {

        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/leaveDeletionRpt");
        List returnList = new ArrayList();



        try {
            returnList = objModel.getLeaveReport(fb);


            if (returnList.size() > 0) {
                mv.addObject("returnList", returnList);


            } else {
                mv.addObject("returnList", null);


            }
        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();


            try {
                throw ex;


            } catch (Exception ex1) {
            }
        }

        return mv;


    }

    public ModelAndView viewGraph(HttpServletRequest req, HttpServletResponse res) {

        ModelAndView mv = new ModelAndView("admin/viewGraph");

        commonFunctions cf = new commonFunctions();
        DefaultPieDataset wfhDataSet = null;
        DefaultPieDataset leaveDataSet = null;

        try {
            objModel = new AdminServiceModel();

            wfhDataSet = objModel.getLeaveSummery("LEAVE");
            mv.addObject("LEAVE", cf.getChart("leave", leaveDataSet));

            leaveDataSet = objModel.getLeaveSummery("WFH");
            mv.addObject("WFH", cf.getChart("wfh", wfhDataSet));



        } catch (Exception ex) {
            //Logger.getLogger(AdminController.class.getName()).log(Level.SEVERE, null, ex);
            //System.out.println(ex);
            ex.printStackTrace();
        }

        return mv;

    }

    public ModelAndView logOutUser(HttpServletRequest req, HttpServletResponse res) {

        ModelAndView mv = new ModelAndView();
        mv.setViewName("admin/logout");



        return mv;

    }
}
