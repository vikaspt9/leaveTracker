/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.apps.leavetracker.dao.impl;

import com.ibm.apps.leavetracker.dao.normaluser.NormalUserDAO;
import com.ibm.apps.leavetracker.formbean.LeaveRptFormBean;
import com.ibm.apps.leavetracker.manager.employee.entitybean.EmployeeBean;
import com.ibm.apps.leavetracker.manager.employee.entitybean.LeaveWfhBean;
import com.ibm.common.commonFunctions;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author Administrator
 */
public class JdbcNormalUserDAO implements NormalUserDAO {

    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;
    commonFunctions comObj = new commonFunctions();

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public boolean validateUser(Map DataMap) {

        boolean returnFlag = false;
        Connection conn = null;
        StringBuilder sql = new StringBuilder();


        try {

            conn = dataSource.getConnection();

            sql.append("SELECT COUNT(*) CNT FROM EMP_MASTER WHERE EMP_ID = ? AND PASSWORD = ? ");
            PreparedStatement pstmt = conn.prepareStatement(sql.toString());

            pstmt.setString(1, DataMap.get("EMPID").toString());
            pstmt.setString(2, DataMap.get("PASSWORD").toString());

//            System.out.print("SQL:" + sql.toString());
//            System.out.print("SQL:" + DataMap.get("USERNAME").toString());
//            System.out.print("SQL:" + DataMap.get("PASSWORD").toString());

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                if (rs.getInt("CNT") == 1) {
                    returnFlag = true;
                }
            }

        } catch (SQLException ex1) {
            System.out.print("ERROR===>" + ex1);
        } catch (Exception ex2) {
            System.out.print("ERROR 2===>" + ex2);
            ex2.printStackTrace();
            try {
                throw ex2;
            } catch (Exception ex) {
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
        }

        return returnFlag;


    }

    public EmployeeBean getUser(Map dataMap) {
        String sql;
        String userName = dataMap.get("EMPID").toString();
        sql = "SELECT * FROM EMP_MASTER WHERE EMP_ID = ? ";
        RowMapper mapper = new RowMapper() {

            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                EmployeeBean eb = new EmployeeBean();
                eb.setEMP_ID(rs.getString("EMP_ID"));
                eb.setFIRST_NAME(rs.getString("FIRST_NAME"));
                eb.setLAST_NAME(rs.getString("LAST_NAME"));
                eb.setIS_ADMIN(rs.getInt("IS_ADMIN"));
                eb.setCONTACT_NO(rs.getLong("CONTACT_NO"));
                eb.setEMAIL(rs.getString("EMAIl"));
                return eb;
            }
        };

        return (EmployeeBean) jdbcTemplate.queryForObject(sql, new Object[]{userName}, mapper);

    }

    public boolean addUser(EmployeeBean eb) {
        System.out.print("HERE IN DAO IMPL CLASSF");
        String sql = " INSERT INTO EMP_MASTER(EMP_ID,PASSWORD,FIRST_NAME,LAST_NAME,CONTACT_NO,EMAIL,IS_ADMIN) VALUES (?,?,?,?,?,?,?)";
        Connection conn = null;
        boolean returnFlg = false;
        try {

            conn = dataSource.getConnection();
            System.out.println("SQL:" + sql);
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, eb.getEMP_ID());
            ps.setString(2, eb.getPASSWORD());
            ps.setString(3, eb.getFIRST_NAME());
            ps.setString(4, eb.getLAST_NAME());
            ps.setLong(5, eb.getCONTACT_NO());
            ps.setString(6, eb.getEMAIL());
            ps.setInt(7, eb.getIS_ADMIN());

            int i = ps.executeUpdate();

            ps.close();

            if (i == 1) {
                returnFlg = true;
            }

        } catch (SQLException ex1) {
            ex1.printStackTrace();
        } catch (Exception ex2) {
            ex2.printStackTrace();
            try {
                throw ex2;
            } catch (Exception ex) {
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
        }

        return returnFlg;


    }

    public List listUser(EmployeeBean eb) {
        String sql;
        List<EmployeeBean> returnList = new ArrayList<EmployeeBean>();
        Connection conn = null;
        try {
            conn = dataSource.getConnection();

            sql = "SELECT * FROM EMP_MASTER WHERE 1=1 ORDER BY FIRST_NAME";
//            if (eb != null && eb.getEMP_ID() != null) {
//                sql += " AND EMP_ID = ?";
//            }

            returnList = jdbcTemplate.query(sql, new BeanPropertyRowMapper(EmployeeBean.class));
        } catch (SQLException ex1) {
            System.out.print("ERROR===>" + ex1);
        } catch (Exception ex2) {
            System.out.print("ERROR 2===>" + ex2);
            ex2.printStackTrace();
            try {
                throw ex2;
            } catch (Exception ex) {
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
        }
        //System.out.println("SIZE===>"+returnList.size());
        return returnList;
    }

    public boolean addLeave(LeaveWfhBean eb) {
        String sql = " INSERT INTO LEAVE_WFH_MASTER(EMP_ID,ENTRY_DATE,LEAVE_TYPE) VALUES (?,STR_TO_DATE(?,'%Y-%m-%d'),?)";
        Connection conn = null;
        boolean returnFlg = false;
        try {

            conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, eb.getEMP_ID());
            ps.setString(2, eb.getENTRY_DATE());
            ps.setString(3, eb.getLEAVE_TYPE());

            int i = ps.executeUpdate();
            System.out.print("iiiiiiiiiii===>" + i);
            ps.close();

            if (i == 1) {
                returnFlg = true;
            }

        } catch (SQLException ex1) {
            System.out.print("ERROR===>" + ex1);
        } catch (Exception ex2) {
            System.out.print("ERROR 2===>" + ex2);
            try {
                throw ex2;
            } catch (Exception ex) {
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
        }

        return returnFlg;
    }

    public boolean updateUser(EmployeeBean eb) {

        String sql = " UPDATE EMP_MASTER SET FIRST_NAME = ?,LAST_NAME = ?,CONTACT_NO = ?,EMAIL = ?,IS_ADMIN = ? WHERE EMP_ID = ?";
        Connection conn = null;
        boolean returnFlg = false;
        try {

            conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, eb.getFIRST_NAME());
            ps.setString(2, eb.getLAST_NAME());
            ps.setLong(3, eb.getCONTACT_NO());
            ps.setString(4, eb.getEMAIL());
            ps.setInt(5, eb.getIS_ADMIN());
            ps.setString(6, eb.getEMP_ID());
            int i = ps.executeUpdate();
            //System.out.print("iiiiiiiiiii===>" + i);
            ps.close();

            if (i == 1) {
                returnFlg = true;
            }

        } catch (SQLException ex1) {
            System.out.print("ERROR===>" + ex1);
        } catch (Exception ex2) {
            System.out.print("ERROR 2===>" + ex2);
            ex2.printStackTrace();
            try {
                throw ex2;
            } catch (Exception ex) {
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
        }

        return returnFlg;
    }

    public List getLeaveReport(LeaveRptFormBean fb) {
        Connection conn = null;
        List arrayList = new ArrayList();
        StringBuilder sql = new StringBuilder();

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            sql.append(" SELECT EM.*,LWM.*,DATE_FORMAT(LWM.ENTRY_DATE,'%d-%M-%Y') LEAVEDATE, ");
            sql.append(" DATE_FORMAT(LWM.ENTRY_DATE,'%M') ENTRYMONTH, ");
            sql.append(" IF(LWM.ENTRY_DATE > SYSDATE(), 'FUTURE' , 'PAST') AS CHKDATE FROM EMP_MASTER EM ");
            sql.append(" LEFT JOIN LEAVE_WFH_MASTER LWM ON (EM.EMP_ID = LWM.EMP_ID) ");
            sql.append(" WHERE 1=1 ");
            if (fb.getCmbEmp() != null && !fb.getCmbEmp().equalsIgnoreCase("-1")) {
                sql.append(" AND EM.EMP_ID IN ( ");
                //System.out.println("==>" + fb.getCmbEmp());
                //System.out.println("==>" + comObj.addQuotes(fb.getCmbEmp()));
                sql.append(comObj.addQuotes(fb.getCmbEmp())).append(" )");
            }
            if (fb.getCmbLeaveType() != null && !fb.getCmbLeaveType().equalsIgnoreCase("-1")) {
                sql.append(" AND UPPER(LWM.LEAVE_TYPE) IN ( ");
                sql.append(comObj.addQuotes(fb.getCmbLeaveType())).append(" )");
            }

            Calendar startDate = new GregorianCalendar();

            startDate.set(fb.getCmbFromYear(), fb.getCmbFromMonth() - 1, fb.getCmbFromDay(), 0, 0, 0);
            startDate.set(Calendar.MILLISECOND, 0);

            Calendar endDate = new GregorianCalendar();
            endDate.set(fb.getCmbToYear(), fb.getCmbToMonth() - 1, fb.getCmbToDay(), 0, 0, 0);
            endDate.set(Calendar.MILLISECOND, 0);

            sql.append(" AND DATE(LWM.ENTRY_DATE) >= '");
            sql.append(df.format(startDate.getTime())).append("' AND DATE(LWM.ENTRY_DATE) <= '");
            sql.append(df.format(endDate.getTime())).append("' ");

            if (fb.getRptType() != null && fb.getRptType().equalsIgnoreCase("EMPWISE")) {
                sql.append(" ORDER BY EM.EMP_ID, EM.FIRST_NAME,LWM.ENTRY_DATE");
            } else if (fb.getRptType() != null && fb.getRptType().equalsIgnoreCase("MONTHWISE")) {
                sql.append(" ORDER BY ENTRY_DATE ASC, EM.FIRST_NAME,LEAVE_TYPE");
            } else if (fb.getRptType() != null && fb.getRptType().equalsIgnoreCase("LEAVEWISE")) {
                sql.append(" ORDER BY LEAVE_TYPE,LWM.ENTRY_DATE,EM.FIRST_NAME ");
            } else {
                sql.append(" ORDER BY ENTRY_DATE ASC, EM.FIRST_NAME,LEAVE_TYPE");
            }
            //System.out.print("sql-->" + sql.toString());
            conn = dataSource.getConnection();
            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery(sql.toString());
            Map dataMap;
            while (rs.next()) {
                dataMap = new HashMap();
                dataMap.put("EMP_ID", rs.getString("EMP_ID"));
                dataMap.put("SRNO", rs.getString("SRNO"));
                dataMap.put("FIRST_NAME", rs.getString("FIRST_NAME"));
                dataMap.put("LAST_NAME", rs.getString("LAST_NAME"));
                dataMap.put("LEAVEDATE", rs.getString("LEAVEDATE"));
                dataMap.put("LEAVE_TYPE", rs.getString("LEAVE_TYPE"));
                dataMap.put("ENTRYMONTH", rs.getString("ENTRYMONTH"));
                dataMap.put("CHKDATE", rs.getString("CHKDATE"));

                arrayList.add(dataMap);
            }

        } catch (SQLException ex1) {
            System.out.print("ERROR===>" + ex1);
        } catch (Exception ex2) {
            System.out.print("ERROR 2===>" + ex2);
            ex2.printStackTrace();
            try {
                throw ex2;
            } catch (Exception ex) {
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
        }

        return arrayList;
    }

    public boolean deleteLeave(Map inputMap) {
        String sql = " DELETE FROM LEAVE_WFH_MASTER WHERE SRNO IN (" + inputMap.get("SRNO").toString() + ")";

        //System.out.println("sql==>" + sql);
        Connection conn = null;
        boolean returnFlg = false;
        try {

            conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);

            int i = ps.executeUpdate();
            ps.close();

            if (i > 0) {
                returnFlg = true;
            }

        } catch (SQLException ex1) {
            System.out.print("ERROR===>" + ex1);
        } catch (Exception ex2) {
            System.out.print("ERROR 2===>" + ex2);
            try {
                throw ex2;
            } catch (Exception ex) {
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
        }

        return returnFlg;
    }

    public DefaultPieDataset getLeaveSummery(String leaveType) {

        StringBuilder sql = new StringBuilder();
        Connection conn = null;
        DefaultPieDataset dataset = new DefaultPieDataset();
        try {

            conn = dataSource.getConnection();
            Statement st = conn.createStatement();

            sql.append("SELECT COUNT(*) CNT, MONTHNAME(ENTRY_DATE) MONTH_NAME, LEAVE_TYPE FROM LEAVE_WFH_MASTER ");
            sql.append(" WHERE LEAVE_TYPE = '").append(leaveType).append("' ");
            sql.append("GROUP BY LEAVE_TYPE,MONTH(ENTRY_DATE) ");
            sql.append(" ORDER BY LEAVE_TYPE ");

            //System.out.print("sql===>" + sql);

            ResultSet rs = st.executeQuery(sql.toString());

            while (rs.next()) {
                dataset.setValue(rs.getString("MONTH_NAME"), rs.getInt("CNT"));
            }


        } catch (SQLException ex1) {
            System.out.print("ERROR===>" + ex1);
        } catch (Exception ex2) {
            System.out.print("ERROR 2===>" + ex2);
            try {
                throw ex2;
            } catch (Exception ex) {
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
        }

        return dataset;
    }
}
