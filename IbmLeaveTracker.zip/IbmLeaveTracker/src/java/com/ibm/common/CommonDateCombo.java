/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.common;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author Administrator
 */
public class CommonDateCombo {

    public static String getMonthCombo(String cmbName, int selectedMonth) {
        String Month[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

        StringBuilder str = new StringBuilder();
        if (selectedMonth == -1) {
            Calendar objCl = new GregorianCalendar();
            selectedMonth = objCl.get(Calendar.MONTH);
        }
        str.append("<select name='").append(cmbName).append("' id='").append(cmbName).append("' >");
        for (int i = 0; i < Month.length; i++) {
            str.append("<option value='").append((i + 1)).append("'");
            if (i == selectedMonth) {
                str.append(" selected ");
            }
            str.append(" >").append(Month[i]).append("</option>");
        }
        str.append("</select>");

        return str.toString();
    }

    public static String getYearCombo(String cmbName, int selectedYear) {
        StringBuilder str = new StringBuilder();
        Calendar objCl = new GregorianCalendar();
        if (selectedYear == -1) {
            selectedYear = objCl.get(Calendar.YEAR);
        }
        str.append("<select name='").append(cmbName).append("' id='").append(cmbName).append("' >");

        for (int i = 2011; i <= objCl.get(Calendar.YEAR); i++) {
            str.append("<option value='").append(i).append("'");
            if (i == selectedYear) {
                str.append(" selected ");
            }
            str.append(" >").append(i).append("</option>");
        }
        str.append("</select>");
        return str.toString();
    }

    public static String getDayCombo(String cmbName, int selectedDay) {
        StringBuilder str = new StringBuilder();
        try {
            Calendar objCl = new GregorianCalendar();
            if (selectedDay == -1) {
                selectedDay = objCl.get(Calendar.DAY_OF_MONTH);
            }

            str.append("<select name='").append(cmbName).append("' id='").append(cmbName).append("' >");
            for (int i = 1; i <= 31; i++) {
                str.append("<option value='").append(i).append("'");
                if (i == selectedDay) {
                    str.append(" selected ");
                }
                str.append(" >").append(i).append("</option>");
            }
            str.append("</select>");
        } catch (Exception ex) {
        }

        return str.toString();
    }
}
