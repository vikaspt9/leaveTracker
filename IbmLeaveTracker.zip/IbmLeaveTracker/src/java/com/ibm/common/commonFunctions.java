/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ibm.common;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import org.jfree.JCommon.*;
import org.jfree.JCommonInfo.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DefaultKeyedValuesDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

/**
 *
 * @author Administrator
 */
public class commonFunctions {

    public String addQuotes(String str) {
        StringBuilder returnString = new StringBuilder();

        if (str.indexOf(",") > 0) {
            String arList[] = str.split(",");
            for (int i = 0; i < arList.length; i++) {
                returnString.append(" '").append(arList[i]).append("',");
            }

            if (returnString.length() > 1) {
                returnString.deleteCharAt(returnString.lastIndexOf(","));
            }
        } else {
            returnString.append("'").append(str).append("' ");
        }

        return returnString.toString();
    }

    public String getChart(String fileName, DefaultPieDataset dataset) throws IOException {

        //DefaultPieDataset dataset = new DefaultKeyedValuesDataset();


        boolean lagend = true;
        boolean tooltips = false;
        boolean urls = false;
        Calendar objCl = new GregorianCalendar();
        String finalFileName = fileName + "_" + objCl.getTimeInMillis() + ".jpg";

        File file = new File("C:\\java_projects\\IbmLeaveTracker\\web\\images\\" + finalFileName);
        JFreeChart chart = ChartFactory.createPieChart(fileName, dataset, lagend, tooltips, urls);

        ChartUtilities.saveChartAsJPEG(file, chart, 400, 500);



        //chart.setBorderPaint(Color.GREEN);

        return finalFileName;
    }
}
