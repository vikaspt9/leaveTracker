/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function callAjax(obj, divID) {
    getData_sync("admin.htm?cmdAction="+obj,divID,false);
    if(document.getElementById("msgDiv")) {
        document.getElementById("msgDiv").innerHTML = "";
    }
    if(document.getElementById("ajaxReportBox")) {
        document.getElementById("ajaxReportBox").innerHTML = "";
    }
    
}

function validateAddUser() {
    var frm = document.frmAddUser;
    if(frm.txtTask.value == "add") {
        getData("admin.htm?cmdAction=insertUser", "msgDiv", getalldata(frm));
    }else {
        getData("admin.htm?cmdAction=updateUser", "msgDiv", getalldata(frm));
    }

    return true;
}

function validateLeave() {
    
    var frm = document.frmAddLeave;
    getData("admin.htm?cmdAction=insertLeave", "msgDiv", getalldata(frm));
    callAjax('addLeave','ajaxBox');
}

function callDelete(obj) {
    if(confirm("Are you sure? you want to delete this Employee? \nThis will delete all the information including Leave/WFH information")) {

}
}

function callEdit(obj) {

    getData("admin.htm?cmdAction=editUser&empid="+obj,"ajaxBox");
    
}

function callLogout() {
    var frm = document.frmLogout;
    frm.action = "logout.htm?cmdAction=logOutUser";
    frm.submit();
}

function dispDateCombo(obj) {
    if(obj == "INDIVIDUAL") {
        document.getElementById("trIndividual").style.display = "";
        document.getElementById("trDateRange").style.display = "none";
    }else {
        document.getElementById("trIndividual").style.display = "none";
        document.getElementById("trDateRange").style.display = "";
    }
}

function showMenu(obj) {
    if(document.getElementById(obj).style.display == "") {
        document.getElementById(obj).style.display = "none";
    }else {
        document.getElementById(obj).style.display = "";
    }
}

function generateReport() {
    var frm = document.frmRpt;
    getData("admin.htm?cmdAction=getReport", "ajaxReportBox", getalldata(frm));
}
function deleteReport() {
    var frm = document.frmRpt;
    getData("admin.htm?cmdAction=getDeleteReport", "ajaxReportBox", getalldata(frm));
}

function deleteLeave() {
    var frm = document.frmDelete;
    if(confirm("Are you sure? You want to delete selected records?")) {
        alert(getalldata(frm));
        getData_sync("admin.htm?cmdAction=DeleteLeaveReport", "msgDiv", getalldata(frm),false);

        getData("admin.htm?cmdAction=getDeleteReport", "ajaxReportBox", getalldata(document.frmRpt));
    }
}