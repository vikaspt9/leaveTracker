/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function validateLogin() {
    var frm = document.frmLogin;

    if(frm.txtLogin.value == ""){
        alert("Please Enter Login ID");
        return false;
    }
    else if(frm.txtPwd.value == "") {
        alert("Please Enter Password");
        return false;
    }

    for(i = 0; i<frm.txtUserType.length;i++){
        if(frm.txtUserType[i].checked == true && frm.txtUserType[i].value == "admin") {
            frm.action = "";
        }else {
            frm.action = "login.htm?cmdAction=validateUser";
        }
    }
    frm.submit();
    return true;
}