var varLoading='<div class="varLoading" align="center"><!--<span>Loading...</span>--!></div>';
var varProblem='<div class="varProblem"><b>Some problem arise.</b></font><center></div>';
var varLoadingMDashboard='<tr><td colspan="100%"><div class="varLoading" align="center"><span>Loading...</span></div></td></tr>';
var varProblemMDashboard='<tr><td colspan="100%"><div class="varProblem"><b>Please Try Again</b></font><center></div></td></tr>';
function getData(dataSource,divID){
    var XMLHttpRequestObject =false;
    if(window.XMLHttpRequest){
        XMLHttpRequestObject=new XMLHttpRequest();
    }else if (window.ActiveXObject){
        XMLHttpRequestObject=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(XMLHttpRequestObject){
        var obj=document.getElementById(divID);
        obj.innerHTML=varLoading;
        XMLHttpRequestObject.open("POST",dataSource);
        XMLHttpRequestObject.send(null);
        XMLHttpRequestObject.onreadystatechange=function(){
            if(XMLHttpRequestObject.readyState==4){
                if(XMLHttpRequestObject.status==200){
                    obj.innerHTML=XMLHttpRequestObject.responseText;
                }else{
                    obj.innerHTML=varProblem;
                }
            }
        }
    }
}
function getData(dataSource,divID,param){
    var XMLHttpRequestObject =false;
    if(window.XMLHttpRequest){
        XMLHttpRequestObject=new XMLHttpRequest();
    }else if (window.ActiveXObject){
        XMLHttpRequestObject=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(XMLHttpRequestObject){
        var obj=document.getElementById(divID);
        obj.innerHTML=varLoading;
        XMLHttpRequestObject.open("POST",dataSource);
        XMLHttpRequestObject.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        XMLHttpRequestObject.send(param);
        XMLHttpRequestObject.onreadystatechange=function(){
            if(XMLHttpRequestObject.readyState==4){
                if(XMLHttpRequestObject.status==200){
                    obj.innerHTML=XMLHttpRequestObject.responseText;
                }else{
                    obj.innerHTML=varProblem;
                }
            }
        }
    }
}
function getDataMobileDashboard(dataSource, divID, param){
    var XMLHttpRequestObject =false;
    if(window.XMLHttpRequest){
        XMLHttpRequestObject = new XMLHttpRequest();
    }else if (window.ActiveXObject){
        XMLHttpRequestObject = new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(XMLHttpRequestObject){
        var obj = document.getElementById(divID);
        obj.innerHTML = varLoadingMDashboard;
        XMLHttpRequestObject.open("POST",dataSource);
        XMLHttpRequestObject.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        XMLHttpRequestObject.send(param);
        XMLHttpRequestObject.onreadystatechange = function(){
            if(XMLHttpRequestObject.readyState == 4){
                if(XMLHttpRequestObject.status == 200){
                    obj.innerHTML = XMLHttpRequestObject.responseText;
                }else{
                    obj.innerHTML = varProblemMDashboard;
                }
            }
        }
    }
}
function getData_sync(dataSource,divID,param,flag){
    var XMLHttpRequestObject =false;
    if(window.XMLHttpRequest){
        XMLHttpRequestObject=new XMLHttpRequest();
    }else if (window.ActiveXObject){
        XMLHttpRequestObject=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(XMLHttpRequestObject){
        var obj=document.getElementById(divID);
        obj.innerHTML=varLoading;
        XMLHttpRequestObject.open("POST",dataSource,flag);
        XMLHttpRequestObject.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        XMLHttpRequestObject.send(param);
        if(XMLHttpRequestObject.readyState==4){
            obj.innerHTML=XMLHttpRequestObject.responseText;
            sessionOver();
        }else {
            obj.innerHTML=varProblem;
        }
    }
}
function getDataValid(dataSource,param){
    var XMLHttpRequestObject =false;
    if(window.XMLHttpRequest){
        XMLHttpRequestObject=new XMLHttpRequest();
    }else if (window.ActiveXObject){
        XMLHttpRequestObject=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(XMLHttpRequestObject){
        XMLHttpRequestObject.open("POST",dataSource,false);
        XMLHttpRequestObject.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        XMLHttpRequestObject.send(param);
        if(XMLHttpRequestObject.readyState==4){
            var t=XMLHttpRequestObject.responseText;
            return Trim(t);
        }else {
            obj.innerHTML=varProblem;
        }
    }
}
function getData_sync_without_img(dataSource,divID,param,flag){
    var XMLHttpRequestObject =false;
    if(window.XMLHttpRequest){
        XMLHttpRequestObject=new XMLHttpRequest();
    }else if (window.ActiveXObject){
        XMLHttpRequestObject=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(XMLHttpRequestObject){
        var obj=document.getElementById(divID);
        XMLHttpRequestObject.open("POST",dataSource,flag);
        XMLHttpRequestObject.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        XMLHttpRequestObject.send(param);
        if(XMLHttpRequestObject.readyState==4){
            obj.innerHTML=XMLHttpRequestObject.responseText;
        }else {
            obj.innerHTML=varProblem;
        }
    }
}
function getalldata(oForm) {
    var aParams=new Array();
    var sParam='';
    for (var i=0 ;i<oForm.elements.length;i++) {
        if (oForm.elements[i].tagName=="SELECT"){
            for(var j=0;j<oForm.elements[i].options.length;j++){
                if(oForm.elements[i].options[j].selected){
                    sParam=encodeURIComponent(oForm.elements[i].name);
                    sParam+="=";
                    sParam+=encodeURIComponent(oForm.elements[i][j].value);
                    aParams.push(sParam);
                }
            }
        }else if(oForm.elements[i].type=="checkbox" && oForm.elements[i].checked==true){
            sParam=encodeURIComponent(oForm.elements[i].name);
            sParam+="=";
            sParam+=encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }else if(oForm.elements[i].type=="radio" && oForm.elements[i].checked==true){
            sParam=encodeURIComponent(oForm.elements[i].name);
            sParam+="=";
            sParam+=encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }else if(oForm.elements[i].tagName=="INPUT" && oForm.elements[i].type=="text"){
            sParam=encodeURIComponent(oForm.elements[i].name);
            sParam+="=";
            sParam+=encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }else if(oForm.elements[i].tagName=="INPUT" && oForm.elements[i].type=="hidden"){
            sParam=encodeURIComponent(oForm.elements[i].name);
            sParam+="=";
            sParam+=encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }else if(oForm.elements[i].tagName=="INPUT" && oForm.elements[i].type=="password"){
            sParam=encodeURIComponent(oForm.elements[i].name);
            sParam+="=";
            sParam+=encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }else if(oForm.elements[i].tagName=="INPUT" && oForm.elements[i].type=="file"){
            sParam=encodeURIComponent(oForm.elements[i].name);
            sParam+="=";
            sParam+=encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }else if(oForm.elements[i].type=="textarea"){
            sParam=encodeURIComponent(oForm.elements[i].name);
            sParam+="=";
            sParam+=encodeURIComponent(oForm.elements[i].value);
            aParams.push(sParam);
        }
    }
    return aParams.join("&");
}
function getResponseText_sync(dataSource,param,flag){
    var XMLHttpRequestObject =false;
    if(window.XMLHttpRequest){
        XMLHttpRequestObject=new XMLHttpRequest();
    }else if (window.ActiveXObject){
        XMLHttpRequestObject=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(XMLHttpRequestObject){
        XMLHttpRequestObject.open("POST",dataSource,flag);
        XMLHttpRequestObject.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        XMLHttpRequestObject.send(param);
        if(XMLHttpRequestObject.readyState==4){
            return XMLHttpRequestObject.responseText;
        }
    }
}
function getDataResponse(dataSource,divID,param,function_name){
    var XMLHttpRequestObject =false;
    if(window.XMLHttpRequest){
        XMLHttpRequestObject=new XMLHttpRequest();
    }else if (window.ActiveXObject){
        XMLHttpRequestObject=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(XMLHttpRequestObject){
        var obj=document.getElementById(divID);
        obj.innerHTML=varLoading;
        XMLHttpRequestObject.open("POST",dataSource);
        XMLHttpRequestObject.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        XMLHttpRequestObject.send(param);
        XMLHttpRequestObject.onreadystatechange=function(){
            if(XMLHttpRequestObject.readyState==4){
                if(XMLHttpRequestObject.status==200){
                    obj.innerHTML=XMLHttpRequestObject.responseText;
                    if(function_name!='' && function_name!='getDataResponse'){
                        eval(function_name+'();');
                    }
                }else{
                    obj.innerHTML=varProblem;
                }
            }
        }
    }
}
function sessionOver(){
    if(document.getElementById("hidnSessOver")!=undefined){
        window.top.location.href="login.fin?cmdAction=showLoginForm";
    }
}
function getData_filter(dataSource,divID,param,flag){
    getDataFilterBase(dataSource,divID,param,flag,false,"Old");
}
function getData_filterNew(dataSource,divID,param,flag){
    getDataFilterBase(dataSource,divID,param,flag,false,"New");
}
function getDataFilter(dataSource,divID,param,flag){
    getDataFilterBase(dataSource,divID,param,flag,false,"Old");
}
function getDataFilterNew(dataSource,divID,param,flag){
    getDataFilterBase(dataSource,divID,param,flag,false,"New");
}
function getDataFilterBase(dataSource,divID,param,flag,selfFilter,OldNew){
    var XMLHttpRequestObject =false;
    if(window.XMLHttpRequest){
        XMLHttpRequestObject=new XMLHttpRequest();
    }else if (window.ActiveXObject){
        XMLHttpRequestObject=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(XMLHttpRequestObject){
        var obj=document.getElementById(divID);
        obj.innerHTML="";
        var loadingImg=document.createElement("img");
        loadingImg.src="https://www.njindiaonline.in/includes/finlibrary/resource/images/nj_loader.gif";
        loadingImg.id="loading_img";
        loadingImg.className="reportLoadingImg";
        loadingImg.title="Loading";
        loadingImg.alt="Loading";
        loadingImg.align="center";
        obj.parentNode.insertBefore(loadingImg ,obj.parentNode.firstChild);
        obj.style.display="none";
        if(document.getElementById("input"+divID)!=null){
            document.getElementById("input"+divID).style.display="none";
        }
        if(document.getElementById("button"+divID)!=null){
            document.getElementById("button"+divID).style.display="none";
        }
        XMLHttpRequestObject.open("POST",dataSource,flag);
        XMLHttpRequestObject.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        XMLHttpRequestObject.send(param);
        if(XMLHttpRequestObject.readyState==4){
            if(sessionHasExpired(XMLHttpRequestObject.responseText)){
                InsertOptionInSelect(divID,XMLHttpRequestObject.responseText);
            }else{
                obj.parentNode.innerHTML="<center>!! ACCESS DENIED !!<br>* Your Session Has Been Expired. Please Login Again *</center>";
                return false;
            }
        }else{
            obj.innerHTML=varProblem;
        }
        obj.parentNode.removeChild(document.getElementById("loading_img"));
        if(OldNew=="New")obj.style.display="";
        if(document.getElementById("input"+divID)!=null){
            document.getElementById("input"+divID).style.display="block";
            document.getElementById("input"+divID).value="";
        }
        if(document.getElementById("button"+divID)!=null){
            document.getElementById("button"+divID).style.display="block";
        }
    }
    if(OldNew=="Old"){
        afterFilter(divID,selfFilter);
    }
    return true;
}
function sessionHasExpired(response){
    var Response=response.replace(/^\s+|\s+$/g,"");
    var responseRows=Response.split('\n') ;
    for(var i =0;i <responseRows.length;i++){
        if(responseRows[i].replace(/^\s+|\s+$/g,"")!=""){
            if((responseRows[i].toLowerCase().search("option")==-1) && (responseRows[i].toLowerCase().search("session") > -1 )){
                return false;
            }
        }
    }
    return true;
}
function InsertOptionInSelect(selectID,CinnerHTML){
    if(ver > -1 && ver<8.0) {
        rawHTML=(CinnerHTML.replace(/^\s+|\s+$/g,"")).split('\n');
        for(i=0;i<rawHTML.length;i++){
            var rawOption=rawHTML[i].replace(/^\s+|\s+$/g,"");
            if(rawOption!=""){
                var rawValueText=rawOption.split('</option>');
                optVal=rawValueText[0].split('>') ;
                var optionText=optVal[1];
                val3=optVal[0].split("value=");
                val4=val3[1].split(" ");
                var optionValue=val4[0].substr(1,val4[0].length-2);
                var objOption=document.createElement('option');
                objOption.innerHTML=optionText;
                objOption.value=optionValue;
                var selected="selected";
                if(optVal[0].search(selected.toLowerCase())!=-1){
                    objOption.selected=true;
                }
                var disabled="disabled";
                if(optVal[0].search(disabled.toLowerCase())!=-1){
                    objOption.disabled=true;
                }
                document.getElementById(selectID).appendChild(objOption);
            }
        }
    }else{
        document.getElementById(selectID).innerHTML=CinnerHTML;
    }
}

function changeLink(url,reportName,rptType,isJavaModule){
    if(rptType=="" || rptType==null){
        rptType=""
    }
    var frm1 = document.newWindFrm1;
    if( reportName == 195 || reportName == 201 || reportName == 205 || reportName == 206|| reportName == 208  || reportName == 210 || reportName == 211|| reportName == 186 || reportName == 95 || reportName == 97 || reportName == 82 || reportName == 89 || reportName == 90 || reportName == 91|| reportName == 93|| reportName == 95 || reportName == 96){
        frm1.target = "_blank";
        frm1.action = "convert.fin?reportName="+reportName+"&rptType="+rptType;
        frm1.submit();
        return;
    }else if(reportName == 246){
        frm1.target = "_self";
        frm1.reportName1.value = reportName;
        frm1.action = "index.fin";
        frm1.submit();
        return;
    }else if(reportName == 270){
        window.open("http://www.njindiainvest.com/marketing/webcasting/eform/eform.htm","Filling_E_Form_demo");
        return;
    }else if(isJavaModule == 1){
        frm1.reportName1.value = reportName;
        frm1.rptType1.value = rptType;
        frm1.action= url;
        if(rptType == 1){
            frm1.target = "_blank";
        }else {
            frm1.target = "_self";
        }
        frm1.submit();
        return;
    }else{
        if(rptType == 1){
            frm1.target = "_blank";
        }else {
            frm1.target = "_self";
        }
        frm1.reportName1.value = reportName;
        frm1.rptType1.value = rptType;
        frm1.action = "convert.fin?reportName="+reportName+"&rptType="+rptType;
        frm1.submit();
        return;
    }
}
function Trim(TRIM_VALUE){
    if(TRIM_VALUE.length < 1)return "";
    TRIM_VALUE = LTrim(TRIM_VALUE);
    TRIM_VALUE = RTrim(TRIM_VALUE);
    if(TRIM_VALUE=="")return "";else return TRIM_VALUE;
}
function RTrim(VALUE){
    var w_space = String.fromCharCode(32);
    var w_enter = String.fromCharCode(10);
    var v_length = VALUE.length;
    var strTemp = "";
    if(v_length < 0)return"";
    var iTemp = v_length -1;
    while(iTemp > -1){
        if(VALUE.charAt(iTemp)==w_space || VALUE.charAt(iTemp)==w_enter )iTemp = iTemp-1;
        else{
            break;
        }
    }
    strTemp = VALUE.substring(0,iTemp +1);
    return strTemp;
}
function LTrim(VALUE){
    var w_space = String.fromCharCode(32);
    var w_enter = String.fromCharCode(10);
    if(v_length < 1)return"";
    var v_length = VALUE.length;
    var strTemp = "";
    var iTemp = 0;
    while(iTemp < v_length){
        if(VALUE.charAt(iTemp)==w_space || VALUE.charAt(iTemp)==w_enter)iTemp = iTemp + 1;
        else{
            break;
        }
    }
    strTemp = VALUE.substring(iTemp,v_length);
    return strTemp;
}